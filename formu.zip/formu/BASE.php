<?php
    
    $servidor = "localhost";
    $usuario = "root";
    $clave = "";
    $baseDeDatos = "formu";

    $enlace = mysqli_connect ($servidor, $usuario, $clave, $baseDeDatos);

?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario Practica 3</title>
    <style>

        .container {
            margin: 20px;
        }

        form {
            max-width: 600px;
            width: 100%;
        }

        
        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group textarea {
            width: calc(100% - 10px); 
            padding: 5px;
            color: #666666;
            border: 1px solid #cccccc;
            border-radius: 5px;
        }
        
        .form-group textarea {
            height: 100px;
        }

        .form-group::after {
            content: "";
            display: block;
            clear: both;
        }
        .button-container {
            margin-top: 15px;
            margin-left: 0;
        }



        .button-container input[type="submit"],
        .button-container input[type="reset"] {
            background-color: #717068; 
            color: white; 
            padding: 10px 20px;
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
            margin-right: 10px; 
        }

        
        body{
            background-color: #B2B1A4;
        }
    </style>
</head>
<body>




<div class="container">
    <form action="#" name="ejemplo" method="post">
        
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" required>
        </div>
        
        <div class="form-group">
            <label for="correo">Correo Electrónico:</label>
            <input type="email" name="correo" required>
        </div>

        <div class="form-group">
            <label for="telefono">Telefono:</label>
            <input type="text" name="telefono" required>
        </div>
        
        <div class="form-group">
            <label for="mensaje">Mensaje:</label>
            <textarea name="mensaje" required></textarea>
        </div>
        
        <div class="form-group">
        <div class="button-container">
                <input type="submit" name="enviar" value="Enviar">
                <input type="reset" value="Restablecer">
            </div>
        </div>
    </form>
</div>
    


</body>
</html>

<?php

    if(isset($_POST['enviar'])){

        $nombre= $_POST ['nombre'];
        $correo= $_POST ['correo'];
        $telefono= $_POST ['telefono'];
        $mensaje= $_POST ['mensaje'];

        $insertarDatos = "INSERT INTO datos (nombre, correo, telefono, mensaje) VALUES ('$nombre', '$correo', '$telefono', '$mensaje')";


        $ejecutarInsertar = mysqli_query($enlace,$insertarDatos);

        header("Location: {$_SERVER['REQUEST_URI']}");exit;
        

    }

?>